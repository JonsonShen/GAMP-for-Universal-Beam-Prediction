clc;clear;close;
%%
load('result.mat')% 6x11 array
% row 1:ML_known
% row 2:error_counter_genie
% row 3:error_counter
% row 4:ML_unknown
% row 5:error_counter_rx
% row 6:error_counter_sample
%%
ML_known=result(1,:);
error_counter_genie=result(2,:);
error_counter=result(3,:);
ML_unknown=result(4,:);
error_counter_rx=result(5,:);
error_counter_sample=result(6,:);
%% 
snr_dB_list=-10:2:10;
n_test=30000;
%% plot
semilogy(snr_dB_list,ML_known,'-s',snr_dB_list,error_counter_genie/n_test,'-o',snr_dB_list,error_counter/n_test,'-hex',snr_dB_list,ML_unknown,'-d',snr_dB_list,error_counter_rx/n_test,'-*',snr_dB_list,error_counter_sample/n_test,'-+');
xlabel('SNR(dB)');ylabel('Prediction error rate');grid on;grid minor;legend('ML known CB','Linear prediction known CB','Universal scheme','ML unknown CB','Linear prediction unknown CB','Legacy scheme');title('Prediction error rate comparison');